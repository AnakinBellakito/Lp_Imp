Nombre: Carlos Vega
Rol: 202073508-5

instruciones Para compilar:
1- make
2- ./simAnimal

------------------------------------------------Notas-------------------------------------------
Programa compila con gcc 11.1.0 pero en gcc(Debian) 10.2.1-6 no compila.
Compila en gcc 9.3.0-17 Ubuntu.
Si el codigo no compila por favor probar mas de una version gcc.

En caso de probar Animal.c por separado descomentar struct Animal y main

Programa funciona pero tiene comportamiento indeterminado a momentos, a veces libera el 100% y otras el 0%
Ejecutar varias veces para darse cuenta gracias.
