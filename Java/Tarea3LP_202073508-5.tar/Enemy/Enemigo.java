package Enemy;

import Player.Jugador;

public interface Enemigo {
    public abstract void combate(Jugador a);
}
