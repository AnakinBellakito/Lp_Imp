Nombre: Carlos Vega Munoz
Rol: 202073508-5

instruciones Para compilar:
1- make
2- make run

------------------------------------------------Notas---------------------------------------------------------------------
* 4 nuevos atributos en Jugador. EnergiaMax, VidaMax, ManaMax y pos
* Declare la lista de misiones en estado protected, ya que al hacerla private no podia inicializarla en el constructor respectivo.
* Declare publico las clases dentro de tierra por un manejo mas comodo dentro y fuera del main considere private pero no pude implementarlo
* Funciones que retornaban 0 o 1 las transforme a boolean false o true respectivamente.
* MakeFile lo cree considerando entorno windows.
* Archivos java creados a traves de VS-Code jdk-17  y extensiones pero compilado y ejecutado a traves de eclipse por problemas con vscode.